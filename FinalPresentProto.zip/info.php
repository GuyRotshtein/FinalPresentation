<?php 
    echo phpinfo();
?>
